import UIKit

class cell : UITableViewCell {
    
    

    @IBOutlet weak var labelText: UILabel!
    
    
}
